let wallet = 0;
let bottles = 0;
let transactions = [];

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if(username && password) {
        document.getElementById('loginPage').style.display = 'none';
        document.getElementById('homePage').style.display = 'block';
        alert("Login successful! (ISRTC login simulation)");
    } else {
        alert("Enter username and password");
    }
}

function logout() {
    document.getElementById('loginPage').style.display = 'block';
    document.getElementById('homePage').style.display = 'none';
}

function scanQR() {
    bottles++;
    wallet += 5;
    transactions.push(`Scanned 1 bottle. Wallet +₹5`);
    updateDashboard();
}

function updateDashboard() {
    document.getElementById('walletBalance').textContent = wallet;
    document.getElementById('bottleCount').textContent = bottles;

    const historyEl = document.getElementById('transactionHistory');
    historyEl.innerHTML = "";
    transactions.forEach((t, index) => {
        let li = document.createElement('li');
        li.textContent = `${index+1}. ${t}`;
        historyEl.appendChild(li);
    });
}